function value = shekel10(x)
%----------------------------------------------------------
% Shekel10 Test Function for Nonlinear Optimization
%
% Taken from "Towards Global Optimisation 2",edited by L.C.W. Dixon and G.P.
% Szego, North-Holland Publishing Company, 1978. ISBN 0 444 85171 2
%
% 0 <= x1 <= 10                 
% 0 <= x2 <= 10
% 0 <= x3 <= 10
% 0 <= x4 <= 10
% fmin = -10.5364098166920
% xmin = [4; 4; 4; 4];
%----------------------------------------------------------

%---------------------------------------------------------%
% http://www4.ncsu.edu/~definkel/research/index.html  
%---------------------------------------------------------%

a = [4, 1, 8, 6, 3, 2, 5, 8, 6, 7;
     4, 1, 8, 6, 7, 9, 5, 1, 2, 3.6;
     4, 1, 8, 6, 3, 2, 3, 8, 6, 7;
     4, 1, 8, 6, 7, 9, 3, 1, 2, 3.6];
c = [ 0.1, 0.2, 0.2, 0.4, 0.4, 0.6, 0.3, 0.7, 0.5, 0.5];
if size(x,1) == 1
 x = x';
end
for i=1:10
 b = (x - a(:,i)).^2;
 d(i) = sum(b);
end
value = -sum((c+d).^(-1));
